<html>
<head><title>LOGIN FORM</title>
</head>
<body>
<form action="verify.php" method="post"> 
    User Name:<br> 
    <input type="text" name="aadhar"><br><br> 
    Password:<br> 
    <input type="password" name="password"><br><br> 
    <input type="submit" name="submit" value="Login"> &nbsp;&nbsp;<input type="reset" name="reset" value="cancel"> 
<br/> <br/><br/>
</form>
<a href='insertedit.php'>Create Account</a>
</body>
</html>

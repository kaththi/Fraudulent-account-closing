<?php
session_start();
if(isset($_POST['submit'])){ 
$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password 
$db_name="test"; // Database name 
$tbl_name="details"; // Table name 

// Connect to server and select database.
$connection = mysql_connect("$host", "$username", "$password"); 
mysql_select_db("$db_name")or die("cannot select DB");

// Get values from form 
$aadhar=$_POST['aadhar'];
$password=$_POST['password'];

$query = "SELECT * FROM $tbl_name WHERE aadhar='$aadhar' LIMIT 1 ";
 $retval = mysql_query( $query, $connection);
 if(mysql_num_rows($retval) == 1)
{
              $query = "SELECT * FROM $tbl_name WHERE aadhar='$aadhar' and password='$password' ";
 $retval = mysql_query( $query, $connection);
   
  while ($rows = mysql_fetch_array($retval, MYSQL_ASSOC) )
{ 
  
 $d_name = $rows['name'];
 $d_lastname = $rows['lastname'];
 $d_aadhar = $rows['aadhar'];
 $d_acc_no = $rows['acc no'];
 $d_type = $rows['type'];
 $d_password = $rows['password'];

       echo "$d_name  $d_lastname<br>$d_aadhar<br>$d_password<br>$d_acc_no";      
} 

// Modify to go to the page you would like 
      
    }else{ 
        echo "not available"; 
     
    } 
}
echo "<a href='login_page.php'>Back to main page</a>";
?> 
<html>
<title>form test</title>
<body>
<table width="300" border="0" align="center" cellpadding="0" cellspacing="1">
<tr>
<td><form name="form1" method="post" action="insert_acc.php">
<table width="100%" border="0" cellspacing="1" cellpadding="3">
<tr>
<td colspan="3"><strong>Insert Data Into mySQL Database </strong></td>
</tr>
<tr>
<td width="71">Firstname</td>
<td width="6">:</td>
<td width="301"><input name="firstname" type="text" id="firstname"></td>
</tr>
<tr>
<td>Lastname</td>
<td>:</td>
<td><input name="lastname" type="text" id="lastname"></td>
</tr>
<tr>
<td>Account Number</td>
<td>:</td>
<td><input name="account number" type="text" id="account number"></td>
</tr>
<tr>
<td>Type</td>
<td>:</td>
<td><input name="type" type="text" id="type"></td>
</tr>
<tr>
<td>Mobile number</td>
<td>:</td>
<td><input name="mobile number" type="text" id="mobile number"></td>
</tr>

<tr>
<td>Aadhar id</td>
<td>:</td>
<td><input name="aadhar" type="text" id="aadhar"></td>
</tr>


<tr>
<td>Password</td>
<td>:</td>
<td><input name="password" type="text" id="password"></td>
</tr>
<tr>
<td colspan="3" align="center"><input type="submit" name="Submit" value="Submit"></td>
</tr>
</table>
</form>
</td>
</tr>
</table>
</body>
</html>
